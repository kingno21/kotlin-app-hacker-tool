package test.lab.dmm.com.mytestapp.models

import test.lab.dmm.com.mytestapp.services.IP

interface MyMobileInfo {
    fun getIP(): String
}