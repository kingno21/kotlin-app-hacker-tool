package test.lab.dmm.com.mytestapp.UI

interface BasicActivity {
    fun init()
    fun bindEvents()
}